package com.Revan.libs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

    private static Connection conexion;



    private  Conexion(){


    }
    public static  Connection crearConexion(){
        if (conexion==null){
            try {
                conexion = DriverManager.getConnection(
                        "jdbc:mysql://localhost/sistema_bancario?useTimezone=true&serverTimezone=UTC", "root", "jiji9898");
            }
            catch (SQLException e){

                System.out.println(e.getMessage());
            }
        }
        return conexion;
    }

}

