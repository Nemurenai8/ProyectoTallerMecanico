package com.Revan;

import com.Revan.libs.Conexion;
import com.Revan.modelos.Usuario;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        ArrayList<Usuario> lista = Usuario.getUsuarios();
        boolean x = true;

        while (x = true) {
            System.out.println("Bienvenido al sistema de Milton, Por favor seleccione una opcion.");
            System.out.println("1. Mostrar nombres de usuarios");
            System.out.println("2. busqueda por identidad");
            System.out.println("3. salir");
            int opcion = Lector.solicitarentero("Seleccione una opcion");

            switch (opcion) {
                case 1:

                    for (Usuario u : lista) {
                        System.out.println(u.getNombreUsuario());

                    }
                    break;
                case 2:

                    String iden = Lector.solicitarCadena("Ingrese la identidad");

                    try {
                        PreparedStatement sentencia = Conexion.crearConexion().prepareStatement("SELECT * FROM usuario where identidad = ?");

                        sentencia.setString(1, iden);
                        ResultSet resultado = sentencia.executeQuery();

                        while (resultado.next()) {


                            System.out.println(resultado.getString(2));
                            System.out.println(resultado.getString(3));
                            System.out.println(resultado.getString(4));
                            System.out.println(resultado.getString(5));
                            System.out.println(resultado.getString(6));
                            System.out.println(resultado.getString(7));
                            System.out.println(resultado.getString(8));


                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                    break;
                case 3:
                    if (opcion==3){
                        break;
                    }
                    break;
            }
            }

        }
    }
