package com.Revan.modelos;

import com.Revan.Lector;
import com.Revan.libs.Conexion;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Usuario {

    private int codigo;
    private String identidad;
    private String nombre;
    private String apellido;
    private String nombreUsuario;
    private String correoElectronico;
    private String telefono;
    private Date creacion;

    public Usuario(String identidad, String nombre, String apellido, String correoElectronico) {
        this.setIdentidad(identidad);
        this.setNombre(nombre);
        this.setApellido(apellido);
        this.setCorreoElectronico(correoElectronico);
    }


    public int getCodigo() {
        return codigo;
    }


    public String getIdentidad() {
        return identidad;
    }

    public void setIdentidad(String identidad) {
        this.identidad = identidad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getNombreUsuario() {


        if (this.nombreUsuario == null) {

            this.nombreUsuario = this.generarNombreUsuario(0);
        }

        return nombreUsuario;
    }
    private String generarNombreUsuario(int cont){



        String tempNombreUsuario = this.nombre.toLowerCase() + "." + this.apellido.toLowerCase();
        if (cont > 0){
            tempNombreUsuario += "." + String.valueOf(cont);
        }
        try {

            PreparedStatement sentencia = Conexion.crearConexion().prepareStatement(
                    "select nombre_usuario from usuario where nombre_usuario =? "
            );
            sentencia.setString(1,tempNombreUsuario);
            ResultSet resultado = sentencia.executeQuery();
            boolean encontrado = false;
            while (resultado.next()){
                encontrado=true;
            }
            if (encontrado){
                generarNombreUsuario(cont + 1);
            }
        } catch (SQLException e) {
            System.err.println("error al general el nombre de usuario");
        }
return  tempNombreUsuario;
    }


    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public Date getCreacion() {
        return creacion;
    }

    public boolean guardar() {

        try {
            PreparedStatement sentencia = Conexion.crearConexion().prepareStatement(
                    "INSERT into usuario (identidad,nombre,apellido,nombre_usuario,correo_electronico,telefono) " +
                            "values (?,?,?,?,?,?)"
            );
            sentencia.setString(1,this.getIdentidad());
            sentencia.setString(2,this.getNombre());
            sentencia.setString(3,this.getApellido());
            sentencia.setString(4,this.getNombreUsuario());
            sentencia.setString(5,this.getCorreoElectronico());
            sentencia.setString(6,this.getTelefono());
            return sentencia.execute();
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
return false;
    }
    public static ArrayList<Usuario> getUsuarios(){
        ArrayList <Usuario> listaUsuarios = new ArrayList<>();
        try {
            int limit =     Lector.solicitarentero("Ingrese un limite de registros a mostrar");
            PreparedStatement sentencia = Conexion.crearConexion().prepareStatement(
                    "select * from usuario limit ? "
            );
            sentencia.setInt(1, limit);
            ResultSet resultado= sentencia.executeQuery();
            while (resultado.next()  ){
                Usuario usuario = new Usuario(
                        resultado.getString("identidad"),
                        resultado.getString("nombre"),
                        resultado.getString("apellido"),
                        resultado.getString("correo_electronico"));
                usuario.codigo = resultado.getInt("codigo");
                usuario.nombreUsuario = resultado.getString("nombre_usuario");
                usuario.creacion = resultado.getDate("creacion");
                listaUsuarios.add(usuario);

            }
        } catch (SQLException e) {
           System.err.println( " algo salio mal" + e.getMessage());
        }
return  listaUsuarios;
    }


    }
